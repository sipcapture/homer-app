The changelog has moved to https://www.elastic.co/guide/en/elasticsearch/client/javascript-api/current/changelog.html

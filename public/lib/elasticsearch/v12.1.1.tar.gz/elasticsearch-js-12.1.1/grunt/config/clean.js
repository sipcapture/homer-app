module.exports = {
  dist: {
    src: ['<%= distDir %>']
  }
};

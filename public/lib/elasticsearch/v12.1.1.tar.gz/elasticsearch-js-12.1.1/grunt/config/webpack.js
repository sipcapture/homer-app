module.exports = {
  browser_clients: [
    require('../../webpack_config/browser'),
    require('../../webpack_config/angular'),
    require('../../webpack_config/jquery'),
  ]
}
